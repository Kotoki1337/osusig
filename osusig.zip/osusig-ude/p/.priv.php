<?php
define("AKEY", "6d261a4febf35feee9b2b4f60c0e27171b1b23c9");