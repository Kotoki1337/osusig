<?php
define("AKEY", "e66448cea1bd91749a7dbc5a061bed02a496daa9");